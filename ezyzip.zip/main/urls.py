from django.urls import path, include
from . import views

urlpatterns = [
    # Home page
    path('', views.home, name='home'),
    
    # About page
    path('about/', views.about, name='about'),
    
    # Search functionality
    path('search/', views.search_results, name='search_results'),
    path('plans/<int:pk>/', views.plan_detail, name='plan_detail'),
    
    # Insurance pages
    path('carinsurance/', views.carinsurance, name='carinsurance'),
    path('familyinsurance/', views.familyinsurance, name='familyinsurance'),
    path('healthinsurance/', views.healthinsurance, name='healthinsurance'),
    path('houseinsurance/', views.houseinsurance, name='houseinsurance'),
    
    # Registration pages
    path('registration/', views.registration, name='registration'),
    path('registration_success/', views.registration_success, name='registration_success'),

]
